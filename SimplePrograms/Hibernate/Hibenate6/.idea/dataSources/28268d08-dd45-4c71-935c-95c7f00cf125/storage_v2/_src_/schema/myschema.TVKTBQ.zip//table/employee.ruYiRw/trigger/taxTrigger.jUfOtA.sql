CREATE TRIGGER taxTrigger
  BEFORE INSERT
  ON employee
  FOR EACH ROW
  SET new.tax=new.salary*0.2;

