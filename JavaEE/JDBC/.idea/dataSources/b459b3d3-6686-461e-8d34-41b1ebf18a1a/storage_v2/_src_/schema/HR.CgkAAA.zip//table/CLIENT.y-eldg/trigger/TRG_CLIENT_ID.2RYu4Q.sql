CREATE TRIGGER TRG_CLIENT_ID
  BEFORE INSERT
  ON CLIENT
  FOR EACH ROW
  begin
    select client_id_seq.nextval
    into :new.id
    from dual;
  end;
/

