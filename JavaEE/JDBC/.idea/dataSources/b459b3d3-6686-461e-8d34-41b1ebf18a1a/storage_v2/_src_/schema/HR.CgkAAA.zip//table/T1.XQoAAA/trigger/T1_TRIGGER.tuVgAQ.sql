CREATE TRIGGER T1_TRIGGER
  BEFORE INSERT
  ON T1
  FOR EACH ROW
  begin
    select t1_seq.nextval into :new.id from dual;
  end;
/

